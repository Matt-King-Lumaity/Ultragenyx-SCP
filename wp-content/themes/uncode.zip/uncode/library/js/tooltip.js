(function($) {
	"use strict";

	UNCODE.tooltip = function() {
	if (typeof jQuery.fn.tooltip !== 'undefined') {
		$('.btn-tooltip').tooltip();
	}
};


})(jQuery);
