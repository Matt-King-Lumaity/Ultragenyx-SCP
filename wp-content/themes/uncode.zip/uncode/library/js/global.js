/* ----------------------------------------------------------
 * Uncode App
 * ---------------------------------------------------------- */
(function() {
    "use strict";
	var UNCODE = window.UNCODE || {};
	window.UNCODE = UNCODE;
})();
